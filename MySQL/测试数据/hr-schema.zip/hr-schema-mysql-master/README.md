# hr-schema-mysql
DML and DDL scripts to generate the HR SQL Schema for MySQL

Check also https://github.com/nomemory/neat-sample-databases-generators for scripts to generate data for various schemas. Data is arbitrary generated.

